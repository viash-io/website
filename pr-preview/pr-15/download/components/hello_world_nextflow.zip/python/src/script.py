file = open(par["output"], 'a+')
file.write("Hello " + par["input"])
file.close()