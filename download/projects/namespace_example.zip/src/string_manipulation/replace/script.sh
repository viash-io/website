output=${par_text/$par_search/$par_replace}
echo $output