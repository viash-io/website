#!/bin/bash

grep -v '^#' "$par_input" > "$par_output"