const fs = require('fs');
fs.writeFileSync(par['output'], 'Hello ' + par['input']);